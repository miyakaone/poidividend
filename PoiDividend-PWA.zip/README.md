# PoiDividend PWA セットアップ手順

このフォルダは、PoiDividend を「自分専用のアプリ」として iPhone / Android に
ホーム画面追加するための一式です。ストア申請も開発者登録も不要です。

データはすべて端末内（ブラウザの localStorage）に保存され、外部には送信されません。

---

## 1. ホスティングする（どこかにファイルを置く）

スマホのブラウザから https:// で開ける場所にこの中身を置く必要があります。
無料で一番簡単なのは GitHub Pages か Netlify Drop です。

### おすすめ: Netlify Drop（一番簡単・登録すら不要）

1. パソコンのブラウザで https://app.netlify.com/drop を開く
2. この `PoiDividend-PWA.zip` を展開したフォルダごと、ページにドラッグ＆ドロップ
3. 数秒で `https://何とか.netlify.app` というURLが発行される
4. そのURLをスマホでアクセスできればOK

### 代替: GitHub Pages

1. GitHubに新しいリポジトリを作成（Private可）
2. このフォルダの中身（index.html, app.jsx, manifest.json, sw.js, icons/）をアップロード
3. リポジトリの Settings → Pages → Source を「main ブランチ」に設定
4. 発行されたURL（https://ユーザー名.github.io/リポジトリ名/）にスマホでアクセス

---

## 2. iPhone でホーム画面に追加

1. Safari（必ずSafari。Chromeだと追加メニューが出ません）で発行されたURLを開く
2. 共有ボタン（四角に上矢印）をタップ
3. 「ホーム画面に追加」をタップ
4. 名前はそのまま「PoiDividend」でOK、右上「追加」をタップ
5. ホーム画面にアイコンが追加されるので、それをタップして起動

## 3. Android（Pixel）でホーム画面に追加

1. Chrome で発行されたURLを開く
2. 右上の「︙」メニューをタップ
3. 「アプリをインストール」または「ホーム画面に追加」をタップ
4. 指示に従って追加

---

## 4. 注意点

- **データは端末ごとに別管理**です。iPhoneで入力したポイントはPixelには自動同期されません（将来Supabase等のバックエンド連携で同期可能になります）
- ブラウザのキャッシュ・サイトデータを消去すると、保存したポイント情報も消えます
- 一度開いておけば、オフライン（機内モード）でも起動できます（Service Workerによるキャッシュ）
- 今は「保有ポイント」「案件管理（サンプルデータ）」「ポートフォリオ（サンプルデータ）」の3画面です。案件の新規登録やAI OCR連携は未実装です

---

## ファイル構成

```
index.html      ... エントリーポイント、CDNからReact/Tailwind/Rechartsを読み込み
app.jsx         ... アプリ本体（画面・ロジックすべてここに統合）
manifest.json   ... PWA設定（アイコン、名前、テーマカラー）
sw.js           ... オフラインキャッシュ用 Service Worker
icons/          ... アプリアイコン（192px, 512px）
```
